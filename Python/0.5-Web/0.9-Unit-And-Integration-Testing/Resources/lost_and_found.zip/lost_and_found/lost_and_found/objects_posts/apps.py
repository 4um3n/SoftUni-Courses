from django.apps import AppConfig


class LostAndFoundAppConfig(AppConfig):
    name = 'lost_and_found.objects_posts'
