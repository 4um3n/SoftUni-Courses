function encodeAndDecodeMessages() {
    console.log('TODO...')
}