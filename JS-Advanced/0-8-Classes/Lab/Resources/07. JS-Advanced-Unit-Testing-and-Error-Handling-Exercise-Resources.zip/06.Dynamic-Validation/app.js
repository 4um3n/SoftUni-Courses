function validate() {
    // TODO
}